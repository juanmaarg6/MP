touch tests//.timeout
CMD="   /home/lcv/Dropbox/Teaching/MP/NetBeans/MP1920Practica4/dist/Debug/GNU-Linux/mp1920practica4   1> tests//.out11 2>&1"
eval $CMD
rm tests//.timeout
