/**
 * @file main.cpp
 * @author DECSAI
 * @note To be implemented by students either completely or by giving them
 * key functions prototipes to guide the implementation
 */


#include <iostream>
#include <string>
#include <fstream>
#include "language.h"
#include "bag.h"
#include "player.h"
#include "move.h"
#include "movelist.h"

using namespace std;

#define ERROR_ARGUMENTS 1
#define ERROR_OPEN 2
#define ERROR_DATA 3
/**
 * @brief Reports an important error and exits the program
 * @param errorcode An integer representing the error detected, which is represented
 * by several symbolic constants: ERROR_ARGUMENTS, ERROR_OPEN y ERROR_DATA
 * @param errorinfo Additional information regarding the error: "" (empty string) for 
 * errors parsing the arguments to main() and, for the case of errors opening or 
 * reading/writing data, the name of the file thas has failed.
 */
void errorBreak(int errorcode, const string & errorinfo);

/**
 * @brief Shows final data
 * @param l Language
 * @param random Random seed
 * @param b Final bag
 * @param p Final player
 * @param original
 * @param legal
 * @param accepted
 * @param rejected
 */
void HallOfFame(const Language &l, int random, const Bag &b, const Player &p, 
        const Movelist& original,const Movelist& legal,
        const Movelist& accepted,const Movelist& rejected);


/**
 * @brief Main function. 
 * @return 
 */
int main(int nargs, char * args[]) {
    Bag bag;
    Player player;
    Language language;
    Move move;

    string lang = "", ifilename = "";
    int Id = -1, score = 0;
    bool correct_reading = true;
    ifstream ifile;
    istream *input;
    /// ...
    ///@warning: Complete the code
    /// ...
    
    /*
    1. El main() recibe como parámetros obligatorios "-l <ID>" y
    "-p <playfile>" y como parámetro opcional "-r <random>" ,
    en cualquier orden entre los tres. En este caso, el parámetro
    "-p" hace referencia a una partida guardada, la cual, por aho-
    ra, sólo tiene los movimientos. Si se especifica "-r" se define
    el aleatorio con el número indicado, si no, no se define aleatorio.
     * 
    2. Crear una instancia de la clase Language con el anterior ID y
    mostrar el conjunto de caracteres permitido para ese lenguaje.
     * 
    3. Crear una instancia de la clase Bag, inicializar el generador de
    números aleatorios con el número aleatorio anterior, si es que
    se ha indicado, y definir su contenido en base al lenguaje que
    se ha declarado anteriormente.
     * 
    4. Crear una instancia de la clase Player y llenarla por comple-
    to con caracteres de la bolsa. Este objeto player deberá estar
    siempre ordenado de la A a la Z.
     * 
    5. Crear una instancia de la clase bf Movelist llamada original
    y leer todos los movimientos desde el fichero indicado en el
    parámetro -p usando el método read(...)
     * 
    6. Crear una instancia de Movelist llamada legal que contenga
    sólo los movimientos de original que están en el diccionario
    del lenguaje elegido. Usar, para ello, el método zip(...)
     * 
    7. Crear dos instancias adicionales de Movelist y llamarlas accepted
    y rejected
     * 
    8. Recorrer toda la lista de movimientos leı́da y, por cada uno de
    ellos.
    a) Si el movimiento está en el diccionario, añadir la palabra a
    la lista accepted , marcarla, calcular su puntuación, según
    el idioma, y mostrarlo en la pantalla.
    b) En otro caso añadirla a la lista rejected y marcarla.
    c) Todos estos mensajes en pantalla no afectan a la validación
    de la práctica, ası́ que el alumno puede implementarlas a
    su propio parecer.
     * 
    9. Terminar con la llamada a HallOfFame para visualizar los re-
    sultados. Esta llamada es la que se utilizará para validar los
    datos.
     * 
    10. Si en cualquier momento se presenta un error en los argumen-
    tos, en la apertura de ficheros o en la lectura de datos del fiche-
    ro, se debe usar la función errorBreak(...) para notificar el error
    y parar el programa.
    */
    
    int arg = 1;
    string sarg = "";
    
    while(arg < nargs) {
        sarg = args[arg];
        
        if(sarg == "-l") {
            arg++;
            if(arg >= nargs)
                errorBreak(ERROR_ARGUMENTS, "");
            
            lang = args[arg++];   
        }
        else if(sarg == "-p"){
            arg++;
            if(arg >= nargs)
                errorBreak(ERROR_ARGUMENTS, "");
            
            ifilename = args[arg++];
            
            ifile.open(ifilename.c_str());
            if(!ifile){
                cerr << "Error opening file " << ifilename << "\n";
                exit(1);
            }
            input = &ifile;
        }        
        else if(sarg == "-r") {
            arg++;
            if(arg >= nargs)
                errorBreak(ERROR_ARGUMENTS, "");
            
            Id = atoi(args[arg++]);         
        }
    }
    
    if(lang == "")
         errorBreak(ERROR_ARGUMENTS, "");
    else
        language.setLanguage(lang);
    
    if(ifilename == "")
         errorBreak(ERROR_ARGUMENTS, "");

    cout << "LANGUAGE: " << lang << "\n";
    
    cout << "ALLOWED LETTERS: " << toUTF(language.getLetterSet()) << "\n";
    
    if(Id >= 0)
        bag.setRandom(Id);
    
    bag.define(language);
    
    cout << "SEED: " << random << "\n";
    
    cout << "BAG (" << bag.size() << "): " << toUTF(bag.to_string()) << "\n";
    
    player.add(bag.extract(7));
    cout << "PLAYER: " << toUTF(player.to_string()) << "\n";
   
    Movelist movements;        /// Original list of movements
    
    correct_reading = movements.read(*input);
    if(correct_reading == false)
        errorBreak(ERROR_DATA, ifilename);
 
    Movelist acceptedmovements, /// Movements accepted in the game
             rejectedmovements; /// Movements not accepted in the game
    Movelist legalmovements(movements);
    
    legalmovements.zip(language);
    
    for(int i = 0; i < legalmovements.size(); i++){        
        move = legalmovements.get(i);

        if(!player.isValid(move.getLetters())){
            rejectedmovements.add(move);
            cout << "READ: ";
            move.print(cout);
            cout << " INVALID!" << "\n";
        }
        else{
            player.extract(move.getLetters());
            player.add(bag.extract(move.getLetters().length()));
            
            score = move.findScore(language);
            move.setScore(score);
            
            acceptedmovements.add(move);

            cout << "READ: ";
            move.print(cout);
            cout << " FOUND!" << score << " points" << "\n";
        }    
        
        cout << "\nPLAYER: " << toUTF(player.to_string());
    }
            
    if(ifilename != "")
        ifile.close();
    
    HallOfFame(language, Id, bag, player, 
            movements, legalmovements, acceptedmovements, rejectedmovements);
    return 0;
}

void HallOfFame(const Language &l, int random, const Bag &b, const Player &p, 
        const Movelist& original,const Movelist& legal,
        const Movelist& accepted,const Movelist& rejected) {
    cout << endl << "%%%OUTPUT" << endl << "LANGUAGE: "<<l.getLanguage()<< " ID: " << random << endl;
    cout << "BAG ("<<b.size()<<"): " << toUTF(b.to_string()) << endl;
    cout << "PLAYER (" <<p.size() << "): " << toUTF(p.to_string());
    cout << endl << endl << "ORIGINAL ("<<original.size()<<"): "<<endl; original.print(cout);
    cout << endl << endl << "LEGAL ("<<legal.size()<<"): "<<endl; legal.print(cout);
    cout << endl << endl << "ACCEPTED ("<<accepted.size()<<") SCORE "<<accepted.getScore()<< ": "<<endl; accepted.print(cout);
    cout << endl << endl << "REJECTED ("<<rejected.size()<<"): "<<endl; rejected.print(cout);
    cout << endl;
}

void errorBreak(int errorcode, const string &errordata) {
    cerr << endl << "%%%OUTPUT" << endl;
    switch(errorcode) {
        case ERROR_ARGUMENTS:
            cerr<<"Error in call. Please use:\n -l <language> -p <playfile> [-r <randomnumber>]"<<endl;
            break;
        case ERROR_OPEN:
            cerr<<"Error opening file "<<errordata << endl;
            break;
        case ERROR_DATA:
            cerr<<"Data error in file "<<errordata << endl;
            break;
    }
    std::exit(1);
}