touch tests//.timeout
CMD="valgrind --leak-check=full  valgrind --leak-check=full /home/juanma/Escritorio/MP/NetBeans/MP1920Practica4/dist/Debug/GNU-Linux/mp1920practica4  1> tests//.out10 2>&1"
eval $CMD
rm tests//.timeout
