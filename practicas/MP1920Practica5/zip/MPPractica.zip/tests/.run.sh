touch tests//.timeout
CMD="valgrind --leak-check=full  valgrind --leak-check=full /home/juanma/Escritorio/MP/NetBeans/MP1920Practica5/dist/Debug/GNU-Linux/mp1920practica5  1> tests//.out17 2>&1"
eval $CMD
rm tests//.timeout
