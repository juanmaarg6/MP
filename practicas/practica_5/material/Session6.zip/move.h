
class Move {
private:
	/// ...
public:
	///...
	// Friend functions
	friend std::ostream& operator<<(std::ostream& os, const Move & m);
	friend std::istream& operator>>(std::istream& is, Move & m);	
};

/**
 * @brief Overload of the insertion operator
 * @param os Output stream (cout)
 * @param m The class to be inserted in the stream
 * @return The output stream (cout)
 */
std::ostream& operator<<(std::ostream& os, const Move & m);
/**
 * @brief Overload of the extraction operator
 * @param os Input stream (cin)
 * @param m The class to be extracted from the stream
 * @return The input stream (cin)
 */
std::istream& operator>>(std::istream& is, Move & m);

#endif /* MOVE_H */
