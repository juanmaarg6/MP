/**
 * @file movelist.h
 * @author DECSAI
 * @note To be implemented by students
 */

#ifndef MOVELIST_H
#define MOVELIST_H

#include "move.h"
#include "language.h"

/**
 * @class Movelist
 * @brief Class used to store a sequence of single movements, where every movement is described in move.h
 */
class Movelist {
public:


	friend std::ostream & operator<<(std::ostream & os, const Movelist & s);
	friend std::istream & operator>>(std::istream & os, Movelist & s);


};
/**
 * @brief Overload of the insertion operator
 * @param os Output stream (cout)
 * @param m The class to be inserted in the stream
 * @return The output stream (cout)
 */
std::ostream & operator<<(std::ostream & os, const Movelist & i);

/**
 * @brief Overload of the extraction operator
 * @param os Input stream (cin)
 * @param m The class to be extracted from the stream
 * @return The input stream (cin)
 */
std::istream & operator>>(std::istream & is, Movelist & i);

#endif

